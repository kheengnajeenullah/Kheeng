# Mai Shayi Investment — DataSub Platform

Prototype (UI/design layer) don wani platform na VTU: Airtime, Data, Electricity,
TV subscription, JAMB/WAEC/NECO/NABTEB PIN, Print Recharge Card, Result Checker,
Recharge Card → Cash, Wallet, Transaction History, da Admin Dashboard.

**Wannan version din code ne kawai na FRONTEND/DESIGN (UI).** Babu ainihin
backend (database, payment, VTU API) tukuna — duk lambobi (balance, transactions,
PINs) mock data ne kawai domin nuna yadda app ɗin zai yi kama.

## Yadda ake gudanar dashi (run locally)

Kana bukatar Node.js (version 18+) a computer ɗinka.

```bash
npm install
npm run dev
```

Bayan wannan, buɗe link ɗin da terminal ya nuna (yawanci `http://localhost:5173`).

## Fayilolin muhimmai

- `src/App.jsx` — duk app ɗin (dukkan shafuka) yana cikin wannan fayil guda
- `index.html` — entry point
- `tailwind.config.js` / `postcss.config.js` — don styling

## Matakan gaba (don ya zama app na gaske)

1. **Backend/API** — Node.js/Express, Laravel, ko Django + database (PostgreSQL/MySQL)
   don users, wallet, transactions.
2. **VTU Provider** — bude asusu tare da kamfani irin su VTpass, ClubKonnect, ko
   Sabinet domin Airtime/Data/Electricity/TV/Exam PIN su yi aiki na gaske ta
   hanyar API dinsu.
3. **Payment Gateway** — Paystack ko Flutterwave domin Fund Wallet (card, bank
   transfer, USSD) su yi aiki na gaske.
4. **Android App** — bayan website ɗin ya gama aiki, ana iya amfani da
   [Capacitor](https://capacitorjs.com) domin turo wannan React app zuwa
   Android app (APK) cikin sauki, ko kuma a sake gina UI a React Native idan
   ana son native performance.

## Sunayen launi (design tokens)

- Background (night indigo): `#0F1024`
- Naira green (primary/success): `#16C784`
- Gold (wallet/premium accent): `#F5B942`
- Alamar musamman (signature): "scratch-card ticket" — siffar katin recharge
  mai perforation, ana amfani da ita don balance card da PIN outputs.
