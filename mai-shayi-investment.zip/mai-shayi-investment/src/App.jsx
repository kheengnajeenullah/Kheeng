import React, { useState } from "react";
import {
  Home, Wallet, History, User, Grid3x3, Smartphone, Wifi, Zap, Tv,
  GraduationCap, FileText, Printer, RefreshCw, ChevronLeft, Plus,
  ArrowDownLeft, ArrowUpRight, CheckCircle2, Eye, EyeOff, Bell,
  LayoutDashboard, Search, Mail, Lock, ChevronRight, Copy, Users2,
  Banknote, ClipboardList, LogOut, ShieldCheck
} from "lucide-react";

/* ---------------------------------------------------------
   DESIGN TOKENS
   Subject: a Nigerian VTU (airtime/data/bills/exam-pin) reseller
   app. Audience: young agents running the business from a phone.
   Signature motif: the recharge-card / scratch-card ticket —
   a perforated card shape used for balances, receipts & pins.
--------------------------------------------------------- */
const C = {
  void: "#0F1024",
  surface: "#171933",
  raised: "#1F2247",
  line: "#2B2E58",
  naira: "#16C784",
  nairaDeep: "#0F9D68",
  gold: "#F5B942",
  text: "#F4F2FC",
  muted: "#9C9AC2",
  danger: "#FF5A5F",
  mtn: "#FFCC00",
  glo: "#00A651",
  airtel: "#ED1C24",
  nmobile: "#00A99D",
};

const FONTS = (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
    .f-display{font-family:'Space Grotesk',sans-serif;}
    .f-body{font-family:'Manrope',sans-serif;}
    .f-mono{font-family:'IBM Plex Mono',monospace;}
    .ticket{position:relative;}
    .ticket::before,.ticket::after{content:'';position:absolute;width:18px;height:18px;background:${C.void};border-radius:9999px;top:50%;transform:translateY(-50%);z-index:2;}
    .ticket::before{left:-9px;}
    .ticket::after{right:-9px;}
    .dashv{background-image:repeating-linear-gradient(to bottom, rgba(244,242,252,0.28) 0 6px, transparent 6px 13px);width:2px;}
    .noscroll::-webkit-scrollbar{display:none;}
    .tapfx{transition:transform .12s ease, opacity .12s ease;}
    .tapfx:active{transform:scale(0.96);opacity:0.9;}
  `}</style>
);

const money = (n) => "\u20a6" + n.toLocaleString("en-NG");

const NETWORKS = [
  { id: "mtn", name: "MTN", color: C.mtn, dark: "#3a2e00" },
  { id: "glo", name: "Glo", color: C.glo, dark: "#04331e" },
  { id: "airtel", name: "Airtel", color: C.airtel, dark: "#3a0c0d" },
  { id: "9mobile", name: "9mobile", color: C.nmobile, dark: "#003330" },
];

const DATA_PLANS = [
  { size: "1GB", price: 350, validity: "30 days" },
  { size: "2GB", price: 600, validity: "30 days" },
  { size: "3.5GB", price: 1000, validity: "30 days" },
  { size: "5GB", price: 1500, validity: "30 days" },
  { size: "10GB", price: 3000, validity: "30 days" },
  { size: "40GB", price: 10000, validity: "30 days" },
];

const DISCOS = ["Ikeja Electric (IKEDC)", "Eko Electric (EKEDC)", "Abuja Electric (AEDC)", "Port Harcourt Electric (PHED)", "Kano Electric (KEDCO)", "Jos Electric (JED)"];

const TV = {
  DStv: [{ n: "Padi", p: 4400 }, { n: "Yanga", p: 6000 }, { n: "Confam", p: 11000 }, { n: "Compact", p: 19000 }, { n: "Premium", p: 44500 }],
  GOtv: [{ n: "Smallie", p: 1900 }, { n: "Jinja", p: 3900 }, { n: "Jolli", p: 5800 }, { n: "Max", p: 8500 }],
  StarTimes: [{ n: "Nova", p: 1700 }, { n: "Basic", p: 3200 }, { n: "Smart", p: 3900 }, { n: "Super", p: 6300 }],
};

const EXAMS = {
  jamb: { label: "JAMB", full: "Joint Admissions & Matriculation Board", price: 7700, note: "UTME ePIN — includes Direct Entry option" },
  waec: { label: "WAEC", full: "West African Examinations Council", price: 3400, note: "Result Checker ePIN (WASSCE)" },
  neco: { label: "NECO", full: "National Examinations Council", price: 1200, note: "Result Checker Token" },
  nabteb: { label: "NABTEB", full: "National Business & Technical Examinations Board", price: 900, note: "Result Checker ePIN" },
};

const TX = [
  { id: 1, type: "Airtime", desc: "MTN \u2022 0803 221 4590", amt: -500, date: "Today, 9:12 AM", status: "Successful" },
  { id: 2, type: "Fund Wallet", desc: "Bank Transfer \u2022 GTBank", amt: 10000, date: "Today, 8:40 AM", status: "Successful" },
  { id: 3, type: "Data", desc: "Glo 5GB \u2022 0805 112 7734", amt: -1500, date: "Yesterday, 6:02 PM", status: "Successful" },
  { id: 4, type: "Electricity", desc: "IKEDC \u2022 Meter 04521190", amt: -8000, date: "Yesterday, 1:15 PM", status: "Successful" },
  { id: 5, type: "WAEC PIN", desc: "Result Checker \u00d7 1", amt: -3400, date: "Mon, 11:47 AM", status: "Pending" },
  { id: 6, type: "Recharge2Cash", desc: "MTN \u20a65,000 card", amt: 4650, date: "Sun, 4:30 PM", status: "Failed" },
];

const statusColor = (s) => s === "Successful" ? C.naira : s === "Pending" ? C.gold : C.danger;

/* ---------------------------------------------------------
   SMALL UI PRIMITIVES
--------------------------------------------------------- */
function TopBar({ title, onBack, right }) {
  return (
    <div className="flex items-center justify-between px-5 pt-6 pb-4">
      <div className="flex items-center gap-3">
        {onBack && (
          <button onClick={onBack} className="tapfx w-9 h-9 rounded-full flex items-center justify-center" style={{ background: C.surface }}>
            <ChevronLeft size={18} color={C.text} />
          </button>
        )}
        <h1 className="f-display text-lg font-semibold" style={{ color: C.text }}>{title}</h1>
      </div>
      {right}
    </div>
  );
}

function Ticket({ children, className = "", style = {} }) {
  return (
    <div className={`ticket rounded-2xl ${className}`} style={{ background: `linear-gradient(135deg, ${C.raised}, ${C.surface})`, border: `1px solid ${C.line}`, ...style }}>
      {children}
    </div>
  );
}

function PerfLine() {
  return (
    <div className="flex flex-col items-center py-2">
      <div className="dashv h-full" style={{ minHeight: "100%" }}></div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="mb-4">
      <label className="f-body text-xs mb-1.5 block" style={{ color: C.muted }}>{label}</label>
      {children}
    </div>
  );
}

function Input(props) {
  return (
    <input {...props} className="f-body w-full rounded-xl px-4 py-3 text-sm outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text }} />
  );
}

function PrimaryBtn({ children, onClick, style = {} }) {
  return (
    <button onClick={onClick} className="tapfx f-body w-full rounded-xl py-3.5 font-semibold text-sm" style={{ background: C.naira, color: "#052014", ...style }}>
      {children}
    </button>
  );
}

function Chip({ active, onClick, children, activeColor }) {
  return (
    <button onClick={onClick} className="tapfx f-body px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap"
      style={{
        background: active ? (activeColor || C.naira) : C.surface,
        color: active ? "#0F1024" : C.muted,
        border: `1px solid ${active ? "transparent" : C.line}`,
      }}>
      {children}
    </button>
  );
}

function Badge({ status }) {
  const col = statusColor(status);
  return (
    <span className="f-body text-[11px] font-semibold px-2 py-0.5 rounded-full" style={{ color: col, background: col + "22" }}>{status}</span>
  );
}

function ServiceIcon({ Icon, bg }) {
  return (
    <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: bg }}>
      <Icon size={20} color={C.void} />
    </div>
  );
}

const SERVICES = [
  { id: "airtime", label: "Airtime", icon: Smartphone, bg: C.naira },
  { id: "data", label: "Data", icon: Wifi, bg: C.gold },
  { id: "electricity", label: "Electricity", icon: Zap, bg: "#7FD1FF" },
  { id: "tv", label: "TV Sub", icon: Tv, bg: "#C9A6FF" },
  { id: "jamb", label: "JAMB", icon: GraduationCap, bg: C.naira },
  { id: "waec", label: "WAEC", icon: FileText, bg: C.gold },
  { id: "neco", label: "NECO", icon: FileText, bg: "#7FD1FF" },
  { id: "nabteb", label: "NABTEB", icon: FileText, bg: "#C9A6FF" },
  { id: "printcard", label: "Print Card", icon: Printer, bg: C.naira },
  { id: "resultchecker", label: "Result Checker", icon: Search, bg: C.gold },
  { id: "r2c", label: "Card \u2192 Cash", icon: RefreshCw, bg: "#7FD1FF" },
];

/* ---------------------------------------------------------
   AUTH SCREEN
--------------------------------------------------------- */
function AuthScreen({ onLogin }) {
  const [mode, setMode] = useState("login");
  const [show, setShow] = useState(false);
  return (
    <div className="h-full flex flex-col px-6 pt-14 pb-8 f-body" style={{ color: C.text }}>
      <div className="flex items-center gap-2 mb-10">
        <div className="ticket w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: C.naira }}>
          <Banknote size={20} color="#052014" />
        </div>
        <span className="f-display text-xl font-bold">Mai Shayi<span style={{ color: C.naira }}>Investment</span></span>
      </div>

      <h2 className="f-display text-2xl font-semibold mb-1">{mode === "login" ? "Welcome back" : "Create your account"}</h2>
      <p className="text-sm mb-8" style={{ color: C.muted }}>{mode === "login" ? "Log in to fund bills in seconds." : "Airtime, data & bills — one wallet."}</p>

      {mode === "register" && (
        <Field label="Full name">
          <div className="relative">
            <User size={16} color={C.muted} className="absolute left-3.5 top-1/2 -translate-y-1/2" />
            <Input placeholder="Chiamaka Okafor" style={{ paddingLeft: "2.5rem" }} />
          </div>
        </Field>
      )}
      <Field label={mode === "login" ? "Phone or email" : "Email address"}>
        <div className="relative">
          <Mail size={16} color={C.muted} className="absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input className="f-body w-full rounded-xl px-4 py-3 text-sm outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text, paddingLeft: "2.5rem" }} placeholder="you@example.com" />
        </div>
      </Field>
      <Field label="Password">
        <div className="relative">
          <Lock size={16} color={C.muted} className="absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input type={show ? "text" : "password"} className="f-body w-full rounded-xl px-4 py-3 text-sm outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text, paddingLeft: "2.5rem", paddingRight: "2.5rem" }} placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" />
          <button onClick={() => setShow(!show)} className="absolute right-3.5 top-1/2 -translate-y-1/2">
            {show ? <EyeOff size={16} color={C.muted} /> : <Eye size={16} color={C.muted} />}
          </button>
        </div>
      </Field>

      {mode === "login" && <p className="text-xs mb-6 text-right" style={{ color: C.gold }}>Forgot password?</p>}

      <PrimaryBtn onClick={onLogin}>{mode === "login" ? "Log in" : "Register"}</PrimaryBtn>

      <p className="text-center text-sm mt-6" style={{ color: C.muted }}>
        {mode === "login" ? "New here? " : "Already have an account? "}
        <button className="font-semibold" style={{ color: C.naira }} onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "Register" : "Log in"}
        </button>
      </p>
    </div>
  );
}

/* ---------------------------------------------------------
   HOME
--------------------------------------------------------- */
function HomeScreen({ go, balance, hideBal, setHideBal }) {
  return (
    <div className="px-5 pt-6 pb-28 f-body">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-xs" style={{ color: C.muted }}>Good morning,</p>
          <p className="f-display text-lg font-semibold" style={{ color: C.text }}>Chiamaka \ud83d\udc4b</p>
        </div>
        <button className="w-10 h-10 rounded-full flex items-center justify-center relative" style={{ background: C.surface }}>
          <Bell size={17} color={C.text} />
          <span className="absolute top-2 right-2.5 w-1.5 h-1.5 rounded-full" style={{ background: C.danger }}></span>
        </button>
      </div>

      <Ticket className="p-5 mb-3">
        <div className="flex items-center justify-between mb-4">
          <span className="text-xs font-medium" style={{ color: C.muted }}>WALLET BALANCE</span>
          <button onClick={() => setHideBal(!hideBal)}>{hideBal ? <EyeOff size={15} color={C.muted} /> : <Eye size={15} color={C.muted} />}</button>
        </div>
        <p className="f-display text-3xl font-bold mb-5" style={{ color: C.text }}>{hideBal ? "\u20a6 \u2022\u2022\u2022\u2022\u2022" : money(balance)}</p>
        <div className="flex gap-2 relative z-10">
          <button onClick={() => go("fundwallet")} className="tapfx flex-1 rounded-xl py-2.5 text-sm font-semibold flex items-center justify-center gap-1.5" style={{ background: C.naira, color: "#052014" }}>
            <Plus size={15} /> Fund Wallet
          </button>
          <button onClick={() => go("history")} className="tapfx flex-1 rounded-xl py-2.5 text-sm font-semibold flex items-center justify-center gap-1.5" style={{ background: C.void, border: `1px solid ${C.line}`, color: C.text }}>
            <History size={15} /> History
          </button>
        </div>
      </Ticket>

      <p className="f-display text-sm font-semibold mb-3 mt-7" style={{ color: C.text }}>Quick services</p>
      <div className="grid grid-cols-4 gap-3 mb-7">
        {SERVICES.slice(0, 8).map((s) => (
          <button key={s.id} onClick={() => go(s.id)} className="tapfx flex flex-col items-center gap-2">
            <ServiceIcon Icon={s.icon} bg={s.bg} />
            <span className="text-[10.5px] text-center leading-tight" style={{ color: C.muted }}>{s.label}</span>
          </button>
        ))}
      </div>

      <div className="flex items-center justify-between mb-3">
        <p className="f-display text-sm font-semibold" style={{ color: C.text }}>Recent activity</p>
        <button onClick={() => go("history")} className="text-xs font-medium" style={{ color: C.naira }}>See all</button>
      </div>
      <div className="space-y-2.5">
        {TX.slice(0, 3).map((t) => <TxRow key={t.id} t={t} />)}
      </div>
    </div>
  );
}

function TxRow({ t }) {
  const positive = t.amt > 0;
  return (
    <div className="flex items-center justify-between rounded-xl px-4 py-3" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: positive ? C.naira + "22" : C.gold + "22" }}>
          {positive ? <ArrowDownLeft size={15} color={C.naira} /> : <ArrowUpRight size={15} color={C.gold} />}
        </div>
        <div>
          <p className="text-sm font-medium" style={{ color: C.text }}>{t.type}</p>
          <p className="text-[11px]" style={{ color: C.muted }}>{t.desc}</p>
        </div>
      </div>
      <div className="text-right">
        <p className="f-mono text-sm font-semibold" style={{ color: positive ? C.naira : C.text }}>{positive ? "+" : "-"}{money(Math.abs(t.amt))}</p>
        <Badge status={t.status} />
      </div>
    </div>
  );
}

/* ---------------------------------------------------------
   SERVICES GRID
--------------------------------------------------------- */
function ServicesScreen({ go }) {
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="All Services" />
      <div className="grid grid-cols-3 gap-4 mt-2">
        {SERVICES.map((s) => (
          <button key={s.id} onClick={() => go(s.id)} className="tapfx flex flex-col items-center gap-2.5 rounded-2xl py-5" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
            <ServiceIcon Icon={s.icon} bg={s.bg} />
            <span className="text-[11px] text-center leading-tight px-1" style={{ color: C.text }}>{s.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------
   WALLET + FUND WALLET
--------------------------------------------------------- */
function WalletScreen({ go, balance }) {
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Wallet" />
      <Ticket className="p-5 mb-5">
        <span className="text-xs font-medium" style={{ color: C.muted }}>AVAILABLE BALANCE</span>
        <p className="f-display text-3xl font-bold mt-2 mb-4" style={{ color: C.text }}>{money(balance)}</p>
        <PrimaryBtn onClick={() => go("fundwallet")}>+ Fund Wallet</PrimaryBtn>
      </Ticket>
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="rounded-xl p-4" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
          <p className="text-[11px] mb-1" style={{ color: C.muted }}>Total funded</p>
          <p className="f-display font-semibold" style={{ color: C.naira }}>{money(184500)}</p>
        </div>
        <div className="rounded-xl p-4" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
          <p className="text-[11px] mb-1" style={{ color: C.muted }}>Total spent</p>
          <p className="f-display font-semibold" style={{ color: C.gold }}>{money(159300)}</p>
        </div>
      </div>
      <p className="f-display text-sm font-semibold mb-3" style={{ color: C.text }}>Wallet activity</p>
      <div className="space-y-2.5">{TX.map((t) => <TxRow key={t.id} t={t} />)}</div>
    </div>
  );
}

function FundWalletScreen({ go }) {
  const [amt, setAmt] = useState("");
  const [method, setMethod] = useState("card");
  const quick = [1000, 2000, 5000, 10000];
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Fund Wallet" onBack={() => go("wallet")} />
      <Field label="Amount">
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm" style={{ color: C.muted }}>\u20a6</span>
          <input value={amt} onChange={(e) => setAmt(e.target.value)} placeholder="0.00" className="f-mono w-full rounded-xl px-4 py-3.5 text-lg outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text, paddingLeft: "1.75rem" }} />
        </div>
      </Field>
      <div className="flex gap-2 mb-6 flex-wrap">
        {quick.map((q) => <Chip key={q} active={String(q) === amt} onClick={() => setAmt(String(q))}>{money(q)}</Chip>)}
      </div>
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Payment method</p>
      <div className="space-y-2.5 mb-8">
        {[
          { id: "card", label: "Debit / Credit Card", sub: "Visa, Mastercard, Verve" },
          { id: "transfer", label: "Bank Transfer", sub: "Instant confirmation" },
          { id: "ussd", label: "USSD", sub: "Pay with a bank code" },
        ].map((m) => (
          <button key={m.id} onClick={() => setMethod(m.id)} className="tapfx w-full flex items-center justify-between rounded-xl px-4 py-3.5" style={{ background: C.surface, border: `1.5px solid ${method === m.id ? C.naira : C.line}` }}>
            <div className="text-left">
              <p className="text-sm font-medium" style={{ color: C.text }}>{m.label}</p>
              <p className="text-[11px]" style={{ color: C.muted }}>{m.sub}</p>
            </div>
            <div className="w-4 h-4 rounded-full flex items-center justify-center" style={{ border: `1.5px solid ${method === m.id ? C.naira : C.muted}` }}>
              {method === m.id && <div className="w-2 h-2 rounded-full" style={{ background: C.naira }}></div>}
            </div>
          </button>
        ))}
      </div>
      <PrimaryBtn>Proceed to pay{amt ? ` \u2022 ${money(Number(amt))}` : ""}</PrimaryBtn>
    </div>
  );
}

/* ---------------------------------------------------------
   AIRTIME / DATA
--------------------------------------------------------- */
function NetworkPicker({ net, setNet }) {
  return (
    <div className="grid grid-cols-4 gap-2.5 mb-6">
      {NETWORKS.map((n) => (
        <button key={n.id} onClick={() => setNet(n.id)} className="tapfx flex flex-col items-center gap-2 rounded-xl py-3" style={{ background: C.surface, border: `1.5px solid ${net === n.id ? n.color : C.line}` }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center f-display text-[10px] font-bold" style={{ background: n.color, color: "#0F1024" }}>{n.name[0]}</div>
          <span className="text-[10.5px]" style={{ color: C.text }}>{n.name}</span>
        </button>
      ))}
    </div>
  );
}

function AirtimeScreen({ go }) {
  const [net, setNet] = useState("mtn");
  const [amt, setAmt] = useState("");
  const quick = [100, 200, 500, 1000, 2000, 5000];
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Buy Airtime" onBack={() => go("services")} />
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Select network</p>
      <NetworkPicker net={net} setNet={setNet} />
      <Field label="Phone number">
        <Input placeholder="0803 000 0000" />
      </Field>
      <Field label="Amount">
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm" style={{ color: C.muted }}>\u20a6</span>
          <input value={amt} onChange={(e) => setAmt(e.target.value)} placeholder="0.00" className="f-mono w-full rounded-xl px-4 py-3.5 text-lg outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text, paddingLeft: "1.75rem" }} />
        </div>
      </Field>
      <div className="flex gap-2 mb-8 flex-wrap">
        {quick.map((q) => <Chip key={q} active={String(q) === amt} onClick={() => setAmt(String(q))}>{money(q)}</Chip>)}
      </div>
      <PrimaryBtn>Buy Airtime{amt ? ` \u2022 ${money(Number(amt))}` : ""}</PrimaryBtn>
    </div>
  );
}

function DataScreen({ go }) {
  const [net, setNet] = useState("mtn");
  const [sel, setSel] = useState(null);
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Buy Data" onBack={() => go("services")} />
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Select network</p>
      <NetworkPicker net={net} setNet={setNet} />
      <Field label="Phone number"><Input placeholder="0803 000 0000" /></Field>
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Choose a plan</p>
      <div className="space-y-2.5 mb-8">
        {DATA_PLANS.map((p) => (
          <button key={p.size} onClick={() => setSel(p.size)} className="tapfx w-full flex items-center justify-between rounded-xl px-4 py-3.5" style={{ background: C.surface, border: `1.5px solid ${sel === p.size ? C.naira : C.line}` }}>
            <div className="text-left">
              <p className="text-sm font-semibold" style={{ color: C.text }}>{p.size} <span className="font-normal" style={{ color: C.muted }}>\u2022 {p.validity}</span></p>
            </div>
            <p className="f-mono text-sm font-semibold" style={{ color: C.naira }}>{money(p.price)}</p>
          </button>
        ))}
      </div>
      <PrimaryBtn>{sel ? `Buy ${sel} Data` : "Select a plan"}</PrimaryBtn>
    </div>
  );
}

/* ---------------------------------------------------------
   ELECTRICITY
--------------------------------------------------------- */
function ElectricityScreen({ go }) {
  const [disco, setDisco] = useState(DISCOS[0]);
  const [type, setType] = useState("prepaid");
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Electricity Bill" onBack={() => go("services")} />
      <Field label="Distribution company (DISCO)">
        <select value={disco} onChange={(e) => setDisco(e.target.value)} className="f-body w-full rounded-xl px-4 py-3 text-sm outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text }}>
          {DISCOS.map((d) => <option key={d}>{d}</option>)}
        </select>
      </Field>
      <div className="flex gap-2.5 mb-4">
        <Chip active={type === "prepaid"} onClick={() => setType("prepaid")}>Prepaid</Chip>
        <Chip active={type === "postpaid"} onClick={() => setType("postpaid")}>Postpaid</Chip>
      </div>
      <Field label="Meter number"><Input placeholder="0452 1190 XXXX" /></Field>
      <Field label="Amount">
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm" style={{ color: C.muted }}>\u20a6</span>
          <input placeholder="0.00" className="f-mono w-full rounded-xl px-4 py-3.5 text-lg outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text, paddingLeft: "1.75rem" }} />
        </div>
      </Field>
      <PrimaryBtn>Pay Bill</PrimaryBtn>
    </div>
  );
}

/* ---------------------------------------------------------
   TV SUBSCRIPTION
--------------------------------------------------------- */
function TVScreen({ go }) {
  const [prov, setProv] = useState("DStv");
  const [sel, setSel] = useState(null);
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="TV Subscription" onBack={() => go("services")} />
      <div className="flex gap-2 mb-5">
        {Object.keys(TV).map((p) => <Chip key={p} active={prov === p} onClick={() => { setProv(p); setSel(null); }}>{p}</Chip>)}
      </div>
      <Field label="Smart card / IUC number"><Input placeholder="1234567890" /></Field>
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Choose a package</p>
      <div className="space-y-2.5 mb-8">
        {TV[prov].map((p) => (
          <button key={p.n} onClick={() => setSel(p.n)} className="tapfx w-full flex items-center justify-between rounded-xl px-4 py-3.5" style={{ background: C.surface, border: `1.5px solid ${sel === p.n ? C.naira : C.line}` }}>
            <p className="text-sm font-semibold" style={{ color: C.text }}>{p.n}</p>
            <p className="f-mono text-sm font-semibold" style={{ color: C.naira }}>{money(p.p)}</p>
          </button>
        ))}
      </div>
      <PrimaryBtn>{sel ? `Subscribe \u2022 ${prov} ${sel}` : "Select a package"}</PrimaryBtn>
    </div>
  );
}

/* ---------------------------------------------------------
   EXAM PIN SCREENS (JAMB / WAEC / NECO / NABTEB)
--------------------------------------------------------- */
function ExamScreen({ go, examId }) {
  const ex = EXAMS[examId];
  const [issued, setIssued] = useState(false);
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title={`${ex.label} ePIN`} onBack={() => go("services")} />
      <p className="text-xs mb-6" style={{ color: C.muted }}>{ex.full}</p>

      {!issued ? (
        <>
          <Field label="Quantity">
            <Input defaultValue="1" type="number" min="1" />
          </Field>
          <div className="rounded-xl px-4 py-3.5 flex items-center justify-between mb-8" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
            <span className="text-sm" style={{ color: C.muted }}>{ex.note}</span>
            <span className="f-mono text-sm font-semibold" style={{ color: C.naira }}>{money(ex.price)}</span>
          </div>
          <PrimaryBtn onClick={() => setIssued(true)}>Pay & Generate PIN</PrimaryBtn>
        </>
      ) : (
        <Ticket className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 size={16} color={C.naira} />
            <span className="text-xs font-semibold" style={{ color: C.naira }}>PIN GENERATED</span>
          </div>
          <p className="text-[11px] mb-1" style={{ color: C.muted }}>{ex.label} Serial No.</p>
          <p className="f-mono text-sm mb-4" style={{ color: C.text }}>WRN{Math.floor(Math.random() * 900000000 + 100000000)}</p>
          <p className="text-[11px] mb-1" style={{ color: C.muted }}>PIN</p>
          <div className="flex items-center justify-between">
            <p className="f-mono text-xl font-bold tracking-widest" style={{ color: C.gold }}>1234-5678-9012</p>
            <Copy size={16} color={C.muted} />
          </div>
        </Ticket>
      )}
    </div>
  );
}

/* ---------------------------------------------------------
   PRINT RECHARGE CARD
--------------------------------------------------------- */
function PrintCardScreen({ go }) {
  const [net, setNet] = useState("mtn");
  const [denom, setDenom] = useState(500);
  const [qty, setQty] = useState(1);
  const [made, setMade] = useState(false);
  const cards = Array.from({ length: made ? qty : 0 });
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Print Recharge Card" onBack={() => go("services")} />
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Network</p>
      <NetworkPicker net={net} setNet={setNet} />
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Denomination</p>
      <div className="flex gap-2 flex-wrap mb-4">
        {[100, 200, 500, 1000].map((d) => <Chip key={d} active={denom === d} onClick={() => setDenom(d)}>{money(d)}</Chip>)}
      </div>
      <Field label="Quantity">
        <Input type="number" min="1" value={qty} onChange={(e) => setQty(Number(e.target.value) || 1)} />
      </Field>
      <PrimaryBtn onClick={() => setMade(true)}>Generate {qty} card{qty > 1 ? "s" : ""} \u2022 {money(denom * qty)}</PrimaryBtn>

      {made && (
        <div className="space-y-4 mt-7">
          {cards.map((_, i) => (
            <Ticket key={i} className="p-4">
              <div className="flex justify-between items-center">
                <span className="f-display text-xs font-bold" style={{ color: NETWORKS.find(n => n.id === net).color }}>{NETWORKS.find(n => n.id === net).name.toUpperCase()} \u2022 {money(denom)}</span>
                <span className="text-[10px]" style={{ color: C.muted }}>#{i + 1}</span>
              </div>
              <div className="my-2" style={{ borderTop: `1px dashed ${C.line}` }}></div>
              <p className="text-[10px]" style={{ color: C.muted }}>SERIAL</p>
              <p className="f-mono text-xs mb-2" style={{ color: C.text }}>{Math.floor(Math.random() * 90000000000 + 10000000000)}</p>
              <p className="text-[10px]" style={{ color: C.muted }}>PIN</p>
              <p className="f-mono text-base font-bold tracking-wider" style={{ color: C.gold }}>{Math.floor(Math.random() * 900000000000 + 100000000000)}</p>
            </Ticket>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------
   RESULT CHECKER (consolidated exam picker)
--------------------------------------------------------- */
function ResultCheckerScreen({ go }) {
  const [ex, setEx] = useState("waec");
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Result Checker" onBack={() => go("services")} />
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Examination body</p>
      <div className="flex gap-2 flex-wrap mb-6">
        {Object.entries(EXAMS).map(([id, e]) => <Chip key={id} active={ex === id} onClick={() => setEx(id)}>{e.label}</Chip>)}
      </div>
      <div className="rounded-xl px-4 py-4 mb-8" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
        <p className="text-sm font-medium mb-1" style={{ color: C.text }}>{EXAMS[ex].full}</p>
        <p className="text-xs" style={{ color: C.muted }}>{EXAMS[ex].note}</p>
      </div>
      <PrimaryBtn onClick={() => go(ex)}>Buy {EXAMS[ex].label} PIN \u2022 {money(EXAMS[ex].price)}</PrimaryBtn>
    </div>
  );
}

/* ---------------------------------------------------------
   RECHARGE CARD -> CASH
--------------------------------------------------------- */
function R2CScreen({ go }) {
  const [net, setNet] = useState("mtn");
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Recharge Card \u2192 Cash" onBack={() => go("services")} />
      <p className="text-xs font-medium mb-2.5" style={{ color: C.muted }}>Network</p>
      <NetworkPicker net={net} setNet={setNet} />
      <Field label="Card PIN"><Input placeholder="Enter 12-digit PIN" /></Field>
      <Field label="Card denomination">
        <select className="f-body w-full rounded-xl px-4 py-3 text-sm outline-none" style={{ background: C.surface, border: `1px solid ${C.line}`, color: C.text }}>
          {[100, 200, 500, 1000, 1500].map((d) => <option key={d}>{money(d)}</option>)}
        </select>
      </Field>
      <div className="rounded-xl px-4 py-3.5 mb-8" style={{ background: C.gold + "18", border: `1px solid ${C.gold}55` }}>
        <p className="text-xs" style={{ color: C.gold }}>Conversion rate: 93% of card value \u2022 credited after verification (up to 30 mins)</p>
      </div>
      <PrimaryBtn>Submit for Conversion</PrimaryBtn>
    </div>
  );
}

/* ---------------------------------------------------------
   TRANSACTION HISTORY
--------------------------------------------------------- */
function HistoryScreen() {
  const [f, setF] = useState("All");
  const filters = ["All", "Airtime", "Data", "Electricity", "WAEC PIN", "Recharge2Cash"];
  const list = f === "All" ? TX : TX.filter((t) => t.type === f);
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Transaction History" />
      <div className="flex gap-2 mb-5 overflow-x-auto noscroll">
        {filters.map((x) => <Chip key={x} active={f === x} onClick={() => setF(x)}>{x}</Chip>)}
      </div>
      <div className="space-y-2.5">
        {list.length ? list.map((t) => <TxRow key={t.id} t={t} />) : (
          <p className="text-sm text-center py-10" style={{ color: C.muted }}>No transactions in this category.</p>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------
   PROFILE
--------------------------------------------------------- */
function ProfileScreen({ go, onLogout }) {
  const items = [
    { label: "Account details", icon: User },
    { label: "Security & PIN", icon: ShieldCheck },
    { label: "Admin Dashboard (demo)", icon: LayoutDashboard, action: () => go("admin") },
  ];
  return (
    <div className="px-5 pt-2 pb-28 f-body">
      <TopBar title="Profile" />
      <div className="flex items-center gap-3 mb-7">
        <div className="w-14 h-14 rounded-full flex items-center justify-center f-display text-lg font-bold" style={{ background: C.naira, color: "#052014" }}>CO</div>
        <div>
          <p className="text-sm font-semibold" style={{ color: C.text }}>Chiamaka Okafor</p>
          <p className="text-xs" style={{ color: C.muted }}>chiamaka@email.com</p>
        </div>
      </div>
      <div className="space-y-2.5 mb-7">
        {items.map((it) => (
          <button key={it.label} onClick={it.action} className="tapfx w-full flex items-center justify-between rounded-xl px-4 py-3.5" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
            <div className="flex items-center gap-3">
              <it.icon size={16} color={C.naira} />
              <span className="text-sm" style={{ color: C.text }}>{it.label}</span>
            </div>
            <ChevronRight size={15} color={C.muted} />
          </button>
        ))}
      </div>
      <button onClick={onLogout} className="tapfx w-full flex items-center justify-center gap-2 rounded-xl py-3.5" style={{ background: C.danger + "18", border: `1px solid ${C.danger}55` }}>
        <LogOut size={15} color={C.danger} />
        <span className="text-sm font-semibold" style={{ color: C.danger }}>Log out</span>
      </button>
    </div>
  );
}

/* ---------------------------------------------------------
   ADMIN DASHBOARD (desktop-style, outside phone frame)
--------------------------------------------------------- */
function AdminDashboard({ exit }) {
  const stats = [
    { label: "Total users", val: "12,480", icon: Users2, color: C.naira },
    { label: "Revenue (30d)", val: money(48239500), icon: Banknote, color: C.gold },
    { label: "Transactions today", val: "1,204", icon: ClipboardList, color: "#7FD1FF" },
    { label: "Pending Card\u2192Cash", val: "8", icon: RefreshCw, color: C.danger },
  ];
  return (
    <div className="min-h-full f-body p-6" style={{ background: C.void }}>
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="f-display text-xl font-bold" style={{ color: C.text }}>Admin Dashboard</p>
          <p className="text-xs" style={{ color: C.muted }}>Mai Shayi Investment \u2022 overview</p>
        </div>
        <button onClick={exit} className="tapfx text-xs font-semibold px-4 py-2 rounded-full" style={{ background: C.surface, color: C.text, border: `1px solid ${C.line}` }}>Exit to app</button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl p-4" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
            <s.icon size={17} color={s.color} />
            <p className="f-display text-lg font-bold mt-3" style={{ color: C.text }}>{s.val}</p>
            <p className="text-[11px]" style={{ color: C.muted }}>{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <div className="rounded-2xl p-4" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
          <p className="f-display text-sm font-semibold mb-3" style={{ color: C.text }}>Recent transactions</p>
          <div className="space-y-2.5">{TX.map((t) => <TxRow key={t.id} t={t} />)}</div>
        </div>

        <div className="rounded-2xl p-4" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
          <p className="f-display text-sm font-semibold mb-3" style={{ color: C.text }}>Users</p>
          <div className="space-y-2.5">
            {[
              { n: "Chiamaka Okafor", e: "agent \u2022 Lagos", bal: 24500 },
              { n: "Ibrahim Musa", e: "agent \u2022 Kano", bal: 8100 },
              { n: "Tolu Adebayo", e: "agent \u2022 Ibadan", bal: 61200 },
              { n: "Ngozi Eze", e: "agent \u2022 Enugu", bal: 3300 },
            ].map((u) => (
              <div key={u.n} className="flex items-center justify-between rounded-xl px-3.5 py-2.5" style={{ background: C.void, border: `1px solid ${C.line}` }}>
                <div>
                  <p className="text-sm font-medium" style={{ color: C.text }}>{u.n}</p>
                  <p className="text-[11px]" style={{ color: C.muted }}>{u.e}</p>
                </div>
                <p className="f-mono text-sm font-semibold" style={{ color: C.naira }}>{money(u.bal)}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------
   BOTTOM NAV + APP SHELL
--------------------------------------------------------- */
const TABS = [
  { id: "home", label: "Home", icon: Home },
  { id: "services", label: "Services", icon: Grid3x3 },
  { id: "wallet", label: "Wallet", icon: Wallet },
  { id: "history", label: "History", icon: History },
  { id: "profile", label: "Profile", icon: User },
];

function BottomNav({ screen, go }) {
  const activeTab = TABS.some((t) => t.id === screen) ? screen : null;
  return (
    <div className="absolute bottom-0 left-0 right-0 px-3 pb-3 pt-2" style={{ background: `linear-gradient(to top, ${C.void} 60%, transparent)` }}>
      <div className="flex items-center justify-between rounded-2xl px-2 py-2" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
        {TABS.map((t) => (
          <button key={t.id} onClick={() => go(t.id)} className="tapfx flex flex-col items-center gap-1 flex-1 py-1.5 rounded-xl" style={{ background: activeTab === t.id ? C.void : "transparent" }}>
            <t.icon size={17} color={activeTab === t.id ? C.naira : C.muted} />
            <span className="text-[9.5px] font-medium" style={{ color: activeTab === t.id ? C.naira : C.muted }}>{t.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [authed, setAuthed] = useState(false);
  const [screen, setScreen] = useState("home");
  const [hideBal, setHideBal] = useState(false);
  const balance = 24350;

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center py-8" style={{ background: "#08091a" }}>
        {FONTS}
        <div className="w-full max-w-sm mx-auto rounded-[2.2rem] overflow-hidden" style={{ background: C.void, minHeight: 780, border: `8px solid #05060f`, boxShadow: "0 30px 60px rgba(0,0,0,0.5)" }}>
          <AuthScreen onLogin={() => setAuthed(true)} />
        </div>
      </div>
    );
  }

  if (screen === "admin") {
    return (
      <div className="min-h-screen" style={{ background: C.void }}>
        {FONTS}
        <AdminDashboard exit={() => setScreen("profile")} />
      </div>
    );
  }

  const renderScreen = () => {
    switch (screen) {
      case "home": return <HomeScreen go={setScreen} balance={balance} hideBal={hideBal} setHideBal={setHideBal} />;
      case "services": return <ServicesScreen go={setScreen} />;
      case "wallet": return <WalletScreen go={setScreen} balance={balance} />;
      case "fundwallet": return <FundWalletScreen go={setScreen} />;
      case "airtime": return <AirtimeScreen go={setScreen} />;
      case "data": return <DataScreen go={setScreen} />;
      case "electricity": return <ElectricityScreen go={setScreen} />;
      case "tv": return <TVScreen go={setScreen} />;
      case "jamb": return <ExamScreen go={setScreen} examId="jamb" />;
      case "waec": return <ExamScreen go={setScreen} examId="waec" />;
      case "neco": return <ExamScreen go={setScreen} examId="neco" />;
      case "nabteb": return <ExamScreen go={setScreen} examId="nabteb" />;
      case "printcard": return <PrintCardScreen go={setScreen} />;
      case "resultchecker": return <ResultCheckerScreen go={setScreen} />;
      case "r2c": return <R2CScreen go={setScreen} />;
      case "history": return <HistoryScreen />;
      case "profile": return <ProfileScreen go={setScreen} onLogout={() => setAuthed(false)} />;
      default: return <HomeScreen go={setScreen} balance={balance} hideBal={hideBal} setHideBal={setHideBal} />;
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-8" style={{ background: "#08091a" }}>
      {FONTS}
      <div className="relative w-full max-w-sm mx-auto rounded-[2.2rem] overflow-hidden" style={{ background: C.void, height: 780, border: `8px solid #05060f`, boxShadow: "0 30px 60px rgba(0,0,0,0.5)" }}>
        <div className="h-full overflow-y-auto noscroll">
          {renderScreen()}
        </div>
        <BottomNav screen={screen} go={setScreen} />
      </div>
    </div>
  );
}
